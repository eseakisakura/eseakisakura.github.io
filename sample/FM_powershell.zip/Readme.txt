﻿　Readme.txt ------

　Powershellで組む、FM音源波形プログラムの、
　サンプルスクリプトです。
　(構造化スクリプトに対応しています。)

　構造化エディタで開くと、
　プログラムの構造が分かりやすいと思います。

　・構造化エディタ sted / 松崎 暁 様
　　https://www.vector.co.jp/soft/win95/writing/se058548.html


　濃い色の波形は、Op.1(モジュレーション、変調波)、
　薄い色の波形は、Op.2(キャリア、搬送波)となってます。


　右クリックから"Powershellで実行"の場合は、
　権限をリモートサインへ変更して下さい。

　Set-ExecutionPolicy RemoteSigned

　または、コンソール上から直接、
　powershell -executionPolicy RemoteSigned .\fm_powershell.ps1

　でも実行できます。


　PS7以降は、コンソール上から直接、

　# $Env:Path+= ";pwsh.exeへのフォルダ" # 一時pathを通す、必要あらば
　pwsh .\fm_powershell.ps1

　のように実行して下さい。

　(PS7以降は、スクリプトの文字コードが、
　shiftJISの場合、エラーになります。)



　　免責事項 /使用条件 /著作権など

　・Apacheライセンス2.0を適用して下さい
　・当スクリプト群を使用して何らかの問題が起こっても、責任を要求しないこと
　・再配布する際は、当ドキュメントファイルを維持して下さい

　Copyright(C) 04coreworks
　https://eseakisakura.wordpress.com/about/
